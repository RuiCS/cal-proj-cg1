var searchData=
[
  ['main',['main',['../main_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main.cpp']]],
  ['maxnewchildren',['maxNewChildren',['../class_graph.html#ab8fd74c3cf8dca6eaa82d39fd1216f52',1,'Graph']]],
  ['myerror',['myerror',['../connection_8cpp.html#ac8b3411018d0e5416c08938b796177ab',1,'connection.cpp']]]
];
