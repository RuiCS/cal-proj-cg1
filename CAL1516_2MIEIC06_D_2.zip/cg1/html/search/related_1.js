var searchData=
[
  ['operator_21_3d',['operator!=',['../class_stop.html#aa1113b92c381868d5df26ee8c3ea0676',1,'Stop']]],
  ['operator_3d_3d',['operator==',['../class_stop.html#a884586ee52e4231c6437a46e989244f7',1,'Stop']]]
];
