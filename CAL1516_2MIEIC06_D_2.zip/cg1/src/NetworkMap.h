/*
 *  NetworkMap.h
 */
#ifndef SRC_NETWORKMAP_H_
#define SRC_NETWORKMAP_H_

#include "Graph.h"
#include "Stop.h"

#include <string>
#include <fstream>
#include <sstream>

using namespace std;

#define SUBWAY_VEL 50
#define SUBWAY_INSTOP 60

#define MIN_LAT 41.14
#define MAX_LAT 41.20
#define MIN_LON -8.56
#define MAX_LON -8.70

#define WIN_WIDTH 3000
#define WIN_HEIGHT 3000
/**
 * Classe que l� e trata de toda a informa��o relativa as linhas.
 */
class NetworkMap {

	Graph<Stop> map;

public:
	/**
	 * Construtor, inicializa o varial map como um grafo vazio.
	 */
	NetworkMap();

	/**
	 * Retorna o grafo com a informa��o das linhas.
	 *
	 * @return Graph<Stop> grafo com a respetiva informa��o.
	 */
	Graph<Stop> getMap() const;

	/**
	 * Iguala o grafo a um novo passado como argumento.
	 *
	 * @param m grafo novo.
	 */
	void setMap(Graph<Stop> m);

	//Methods

	/**
	 * Le o ficheiro passado como argumento e processa a informa��o para o grafo.
	 *
	 * @param filepath caminho para o ficheiro.
	 * @return bool true se � poss�vel ler, false case n�o seja.
	 */
	bool loadMap(string filepath);

	/**
	 * Imprime o grafo na consola.
	 */
	void displayMap();

	/**
	 * Calcula o peso total entre duas paragens.
	 *
	 * @param s1 paragem 1.
	 * @param s2 paragem 2.
	 * @return float peso total das arestas entre as duas paragens.
	 */
	float pathWeight(const Stop& s1, const Stop &s2);
	/**
	 * Calcula o caminho entre duas paragens com peso menor.
	 *
	 * @param s1 Codigo da paragem 1.
	 * @param s2 Codigo da paragem 2.
	 * @param weight peso total
	 * @return vector<Stop> vetor com todas as paragens do caminho com menor peso.
	 */
	vector<Stop> findLightestPath(string s1, string s2, float& weight);
	/**
	 * Calcula o caminho mais r�pido entre duas paragens.
	 *
	 * @param s1 Codigo da paragem 1.
	 * @param s2 Codigo da paragem 2.
	 */
	void findFastestPath(string s1, string s2);
	/**
	 * Calcula o caminho mais barato entre duas paragens.
	 *
	 * @param s1 Codigo da paragem 1.
	 * @param s2 Codigo da paragem 2.
	 */
	void findCheapestPath(string s1, string s2);
	/**
	 * Calcula o caminho mais curto entre duas paragens.
	 *
	 * @param s1 Codigo da paragem 1.
	 * @param s2 Codigo da paragem 2.
	 */
	void findShortestPath(string s1, string s2);
	/**
	 * Calcula o caminho com menos trocas de veiculo entre duas paragens.
	 *
	 * @param s1 Codigo da paragem 1.
	 * @param s2 Codigo da paragem 2.
	 */
	void findLeastLineSwitchesPath(string s1, string s2);
	/**
	 * Verifica os pontos de articul��o do grafo.
	 */
	void getArt();
};

/**
 * Verifica se o vetor com dado elemento
 *
 * @param v vetor
 * @param s elemento
 * @return bool true caso contenha,false caso nao encontre.
 */
bool exists_in_vector(vector<string> v, string s);
/**
 * Imprime no elemento NetworkMap num interface grafica
 */
void graphView(NetworkMap nm);
/**
 * Procura por um vertice num vetor de vertices
 *
 * @param vertexSet vetor
 * @param to_find vertice a encontrar
 * @return int indice do vertice no vetor, -1 caso nao exista
 */
int findVertexInVector(vector <Vertex<Stop>*> vertexSet, Vertex<Stop>* to_find);
/**
 * Atualiza o peso dos vertices de um NetworkMap com uma fun��o passada como argumento
 *
 * @param weightFunction fun�ao para calcular o peso dos vertices
 * @param nm NetworkMap a ser atualizado
 */
void resetEdges(float(*weightFunction)(const Stop&, const Stop&), NetworkMap& nm);
/**
 * Calcula o pre�o de uma viagem com base no numero de zonas em que esta passa.
 *
 * @param numZones numero de zonas
 * @return float pre�o
 */
float calcPrice(int numZones);

// Methods to calculate edge weight
/**
 * Calcula o peso entre a paragem s1 e s2 com base no tempo a que se demora a chegar de s1 a s2.
 *
 * @param s1 paragem 1
 * @param s2 paragem 2
 * @return float peso da aresta em termos de tempo.
 */
float timeWeight(const Stop& s1, const Stop& s2);
/**
 * Calcula o peso entre a paragem s1 e s2 com base no pre�o que se paga ao viajar de s1 ate s2.
 *
 * @param s1 paragem 1
 * @param s2 paragem 2
 * @return float peso da aresta em termos de tpre�o.
 */
float priceWeight(const Stop& s1, const Stop& s2);
/**
 * Calcula o peso entre a paragem s1 e s2 com base na distancia entre s1 e s2.
 *
 * @param s1 paragem 1
 * @param s2 paragem 2
 * @return float peso da aresta em termos de distancia.
 */
float distanceWeight(const Stop& s1, const Stop& s2);
/**
 * Calcula o peso entre a paragem s1 e s2 com base no numero de trocas a que se efetua para ir de s1 a s2.
 *
 * @param s1 paragem 1
 * @param s2 paragem 2
 * @return float peso da aresta em termos de trocas.
 */
float lineSwitchWeight(const Stop&s1, const Stop& s2);


#endif /* SRC_NETWORKMAP_H_ */
